#### Search
---

A front-end for Google Search, Google Image Search, and Google Advanced Search.

This was Project 0 of HarvardX's CS50w course, and served as a quick refresher on working with HTML forms and styling using *Sass*.

#### Resources
---

Sass: https://sass-lang.com/

Harvard's CS50 Web Programming with Python and JavaScript course: https://courses.edx.org/courses/course-v1:HarvardX+CS50W+Web/course/

Full project specification here: https://cs50.harvard.edu/web/2020/projects/0/search/